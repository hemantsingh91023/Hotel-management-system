drop user hotel cascade
/
create user hotel identified by hotel 
/
grant dba to hotel
/
conn hotel/hotel
/
create table login 
(
	id nvarchar2(10),
	pwd nvarchar2(10)
)
/
insert into login values('hotel','hotel')
/
create table hotels
(
hotel_id nvarchar2(20),
hotel_code nvarchar2(10),
hotel_name nvarchar2(20),
hotel_address nvarchar2(20),
hotel_postcode nvarchar2(20),
hotel_city nvarchar2(10),
hotel_url nvarchar2(20)
)
/
create table guests
(
guest_number nvarchar2(10),
guest_name nvarchar2(20),
guest_address nvarchar2(40),
guest_city nvarchar2(10)
)
/
create table hotel_rooms
(
room_number nvarchar2(5),
room_floor nvarchar2(5),
room_floor_count nvarchar2(5)
)
/
create table room_bookings
(
date_booking_from nvarchar2(40),
date_booking_to nvarchar2(20),
room_count nvarchar2(5)
)
/
create table bookings
(
booking_id nvarchar2(10),
date_from nvarchar2(40),
date_to nvarchar2(20)
)
/
create table ref_room_types
(
room_type_code nvarchar2(10),
room_standard_rate nvarchar2(60),
room_type_desc nvarchar2(20),
smoking_yn nvarchar2(20)
)
/
create table period_room_rates
(
room_rate nvarchar2(20)
)
/
create table ref_countries
(
country_code nvarchar2(5),
country_currency nvarchar2(20),
country_name nvarchar2(10)
)
/
create table ref_hotel_characters
(
character_id nvarchar2(20),
character_code nvarchar2(20),
character_desc nvarchar2(5)
)
/
create table room_rate_periods
(
rate_period nvarchar2(20),
rate_period_desc nvarchar2(20)
)
/
create table ref_star_ratings
(
star_rating_id nvarchar2(20),
star_rating_code nvarchar2(5),
star_rating_image nvarchar2(20)
)
/
create table hotel_chains
(
hotel_chain_code nvarchar2(20),
hotel_chain_name nvarchar2(20)
)
/


